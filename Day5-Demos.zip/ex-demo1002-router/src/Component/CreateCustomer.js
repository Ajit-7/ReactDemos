import React, { Component } from 'react'
import {NavLink} from 'react-router-dom'  
import axios from 'axios'
import "./CreateCustomer.module.css"
export class CreateCustomer extends Component{
    
    
    
    render(){
        return (
            <div>
                <center>
                    <h2>Create Customer</h2>     
    
					<NavLink to="/" >Home</NavLink>  

                </center>

            </div>
        )
    }
}
