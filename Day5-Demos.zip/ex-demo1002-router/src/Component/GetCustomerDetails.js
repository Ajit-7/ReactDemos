import React, { Component } from 'react'
import {NavLink} from 'react-router-dom' 
import axios from 'axios'
import "./CreateCustomer.module.css" 
export class  GetCustomerDetails  extends Component  {




    render(){
        return (
            <div>
                <center>
                    <h2>Get Customer Details</h2>  

                    <NavLink to="/">Home</NavLink>     
                </center>
            </div>
        )
    }
}
