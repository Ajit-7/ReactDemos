import React, { Component } from 'react'
import {NavLink} from 'react-router-dom'  
import axios from 'axios'
import "./CreateCustomer.module.css"
export class DeleteCustomerById extends Component {


    constructor(props) {
        super(props)
    
        this.state = {
            customerId:0,
            message:"",
            list:[],
            errorMessage:""
        }
    }
    
    //Function to place the call to get the Customer details
    //same will be used during componentMount phase and after successful deletion to fetch the 
    //fresh customer list.
    populateDropDown(){
        //Get
        //Placing Request to Spring Boot App for getting all details
        axios.get("http://localhost:8095/cust/controller/getDetails")//Promise based / non blocking response is returned
        .then(
             //Case of Success, get the response data and update     
             //the required state (list)
            response=> {
                console.log("Go result"+response);
                this.setState({list: response.data})
            }
        ).catch(error=>{
                //Case of Failure setting the error message
                console.log(error)
                this.setState({errorMessage:error.message})
        });
    }

    //Fetching Details on Load/ mount of the component
    componentDidMount(){
        this.populateDropDown();
    }
    //Commen handler
    handlerCommenValuesUpdate = event=>{
        this.setState(
            {[event.target.name]:event.target.value}
        )
    }
    //Submission Handler
    submitHandler = event=>{
        event.preventDefault();
        console.log(this.state);
        //sending the post data to the server
        axios.delete("http://localhost:8095/cust/controller/deleteCust/"+ this.state.customerId)
        .then(
            response=> {	    //Case of Success, get the response data and update     
                                //the required state (message)
                console.log("Got result"+response);
                this.setState({message: "Customer with name: "+response.data.customerName+", deleted successfully...."})
                //Clearing errorMessage in case of successs
                this.setState({errorMessage:""})
                
                //Populating Drop Down with Fresh enteries
                this.populateDropDown();
                
            }
        ).catch(error=>{
                console.log(error)
                this.setState({errorMessage:error.message})
                //Clearing message in case of error
                this.setState({message:""})
        });

    }

    
    render() {
        const {customerId,list,message,errorMessage} = this.state
        let optionItems = list.map((it) =>
                <option value={it.customerId}>{it.customerName}</option>
            );
        return (
            <div>
                <center>
                    <h2>Delete CustomerId</h2>
                    <form onSubmit={this.submitHandler}>
                        <table>
                                 <tr>
                                    <td>Select Customer</td>
                                    <td>
                                        <select name="customerId" value={customerId} onChange= {this.handlerCommenValuesUpdate}>
                                            <option value="">--Select--</option>
                                            {optionItems}
                                        </select>

                                    </td>
                                </tr>
                        </table>
                        <br/>
                        <input type="submit" value="Submit"/>
                        <h4>{message?message:errorMessage}</h4>
                    </form>

                    <br/><br/><br/>
                    <NavLink to="/" >Home</NavLink>  
                </center>
            </div>
        )
    }
}

export default DeleteCustomerById
