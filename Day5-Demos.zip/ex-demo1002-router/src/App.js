import React from 'react';
import logo from './logo.svg';
import './App.css';
import {NavLink} from 'react-router-dom'  
function App() {
  return (
    <div className="App">
      <h2>Welcome to Customer Management System</h2>
      
          <br/>
           
      
      
    </div>
  );
}


export default App;
