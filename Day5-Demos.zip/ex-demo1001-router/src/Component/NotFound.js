import React from 'react'
import {NavLink} from 'react-router-dom'  
function NotFound() {
    return (
        <div>
            <center>
            <h3>Please select a valid Option from Home Page..</h3>
            <br/><br/><br/>
                <NavLink to="/">Home</NavLink>     
            </center>    
        </div>
    )
}

export default NotFound
