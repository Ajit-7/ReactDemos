import React from 'react'
import {NavLink} from 'react-router-dom'  
export function GetCustomerDetails() {
    return (
        <div>
            <center>
                <h2>Get Customer Details</h2>  
                <br/><br/><br/>
                <h4>Pending to code the functionality....</h4>
                <br/><br/><br/>
                <NavLink to="/">Home</NavLink>     
            </center>
        </div>
    )
}
