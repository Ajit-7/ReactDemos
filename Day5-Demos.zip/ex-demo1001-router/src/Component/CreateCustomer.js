import React from 'react'
import {NavLink} from 'react-router-dom'  
export function CreateCustomer() {
    return (
        <div>
            <center>
                <h2>Create Customer</h2>     
                <br/><br/><br/>
                    <h4>Pending to code the functionality....</h4>
                <br/><br/><br/>
                <NavLink to="/" >Home</NavLink>  
      
            </center>

        </div>
    )
}
