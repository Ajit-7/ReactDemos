import React from 'react';
import logo from './logo.svg';
import './App.css';
import {NavLink} from 'react-router-dom'  
function App() {
  return (
    <div className="App">
      <h2>Welcome to Customer Management System</h2>
      
          <br/>
          <NavLink to="/AddCustomer">Create Customer</NavLink> <br/><br/><br/>  

          <NavLink to="/GetCustomers">Get Customer Details</NavLink>  
      
      
    </div>
  );
}


export default App;
