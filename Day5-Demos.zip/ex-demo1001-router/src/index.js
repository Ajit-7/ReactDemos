import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import { CreateCustomer } from './Component/CreateCustomer';
import { GetCustomerDetails } from './Component/GetCustomerDetails';
import { Route, Switch , BrowserRouter as Router} from 'react-router-dom'  
import NotFound from './Component/NotFound';


//Step1: Creating a Router which will help to map the components to the Navlink URLS to the Components.
const routing = (  
  <Router>  
    <div>  
      <Switch>
        <Route exact path="/" component={App} />  
        <Route path="/AddCustomer" component={CreateCustomer} />  
        <Route path="/GetCustomers" component={GetCustomerDetails} />  
        <Route component={NotFound}></Route>
      </Switch>
    </div>  
  </Router>  
)  
//Earlier Render
// ReactDOM.render(
//   <React.StrictMode>
//     <App />
//   </React.StrictMode>,
//   document.getElementById('root')
// );
//Step2: Rendering with the Router Enabled. This will help to Load the components on the same page on end user’s request
ReactDOM.render(routing, document.getElementById('root')); 

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
