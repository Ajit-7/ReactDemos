import React from 'react';
import { EmployeeWithBugs } from './Component/EmployeeWithBugs';
import { SpreadOperator } from './Component/SpreadOperator';
import { EmployeeWithBugsFixed } from './Component/EmployeeWithBugsFixed';

function App() {
  return (
    <div className="App">
     {/* <EmployeeWithBugs></EmployeeWithBugs> */}
     {/* <SpreadOperator></SpreadOperator> */}
     <EmployeeWithBugsFixed></EmployeeWithBugsFixed>
    </div>
  );
}

export default App;
