import React, {useState} from 'react'
import  "./EmployeeForm.module.css"
export function EmployeeWithBugs() {
    //Step1
    const initialObj={employeeName:'',salary:'',departmentCode:''}

    const [newObj,setCommenHandler] = useState(initialObj)

    //Handler to be invoked when button is clicked
    function submitHandler(){
        alert("Data in EmployeeObject:  "+JSON.stringify(newObj))
    }

    return (
        <div>
            <center>
                <br/><br/><br/><br/><br/>
                <h2>Changing Object using useState hook, with bugs</h2>
            <table>
                <tbody>
                    <tr>
                        <td>Employee Name</td> {/**Step2 and 3 */}
                        <td><input type="text" value={newObj.employeeName} onChange={event=>setCommenHandler({employeeName:event.target.value})}/> </td>
                    </tr>
                    <tr>
                        <td>Salary</td>  {/**Step2 and 3 */}
                        <td><input type="text" value={newObj.salary} onChange={event=>setCommenHandler({salary:event.target.value})}/> </td>
                    </tr>
                    <tr>
                        <td>Department Code</td>  {/**Step2 and 3 */}
                        <td><input type="text" value={newObj.departmentCode} onChange={event=>setCommenHandler({departmentCode:event.target.value})}/> </td>
                    </tr>
                </tbody>
            </table>
            <br/><button onClick={submitHandler} > Register</button>
           </center>
        </div>
    )
}