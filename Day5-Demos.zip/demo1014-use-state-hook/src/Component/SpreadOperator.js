import React from 'react'
import  "./EmployeeForm.module.css"
export function SpreadOperator() {
    const obj1={employeeName:'Jack',salary:'1001',departmentCode:'1001'}
    const obj2={gender:"M",salary:'23000', country:"India"}
    return (
        <div>
            <center>
                <h2>Spread Opreator Demo</h2>

            <h4>
                Obj1: {JSON.stringify(obj1)} <br/>
                Obj2: {JSON.stringify(obj2)}<br/>
                <br/>
                <table>
                    <tr>
                        <td>
                            {`More than one properties togather: {...obj1,...obj2}`} 
                        </td>  
                        <td>
                        {JSON.stringify({...obj1,...obj2})}
                        </td>
                    </tr>
                    
                    <tr>
                        <td>
                            {`Update more than one properties togather: {...obj2,...obj1}`}   
                        </td>
                        <td>
                            {JSON.stringify({...obj2,...obj1})}
                        </td>
                    </tr>
                    <tr>
                        <td>
                            {`Update only one property: `} <br/>
                            {`{...obj1,employeeName:'FinalChanged}'`}   
                        </td>    
                        <td>
                            {JSON.stringify({...obj1,employeeName:'FinalChanged'})}
                        </td>
                    </tr>
                </table>
            </h4>
            </center>
        </div>
    )
}
