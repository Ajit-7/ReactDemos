import React, {useState,useEffect} from 'react'
import  "./EmployeeForm.module.css"
export function EmployeeWithBugsFixed2() {
    //Step1
    const initialEmployeeObj={employeeName:'',salary:'',departmentCode:''}
    const initialAssetObj = {assetName:'',descriptionComments:''}

    const [newEmployeeObj,setCommonHandlerForEmployee] = useState(initialEmployeeObj)
    const [newAssetObj,setCommonHandlerForAsset] = useState(initialAssetObj)


    //Effects will get executed for mounting and stateUpdates
    useEffect(()=>{
        console.log("Invoking Mounting and update Effect For Employee"); 
    },[newEmployeeObj]) //Gets executed only on component mounting and if updated are done to newEmployeeObj state

    useEffect(()=>{
        console.log("Invoking Mounting and update Effect For Asset"); 
    },[newAssetObj]) //Gets executed only on component mounting and if updated are done to newAssetObj state

    
    //Effect will get executed for mounting only but not for state updates
    useEffect(()=>{
        console.log("Invoking Mounting Effect"); 
    },[])


    //Handler to be invoked when button is clicked
    function submitHandler(){
        alert("Data in EmployeeObject:  "+JSON.stringify(newEmployeeObj)
            +",Asset Data: "+JSON.stringify(newAssetObj))

    }

    return (
        <div>
            <center>
                <br/><br/><br/><br/><br/><br/><br/>
                <h2>Changing Object using useState hook</h2>
            <table>
                <tbody>
                    <tr>
                        <td>Employee Name</td> {/**Step2 and 3 */}
                        <td><input type="text" value={newEmployeeObj.employeeName} onChange={event=>setCommonHandlerForEmployee({...newEmployeeObj,employeeName:event.target.value})}/> </td>
                    </tr>
                    <tr>
                        <td>Salary</td>  {/**Step2 and 3 */}
                        <td><input type="text" value={newEmployeeObj.salary} onChange={event=>setCommonHandlerForEmployee({...newEmployeeObj,salary:event.target.value})}/> </td>
                    </tr>
                    <tr>
                        <td>Department Code</td>  {/**Step2 and 3 */}
                        <td><input type="text" value={newEmployeeObj.departmentCode} onChange={event=>setCommonHandlerForEmployee({...newEmployeeObj,departmentCode:event.target.value})}/> </td>
                    </tr>
                </tbody>
            </table>
            <h4>Asset For Employee</h4>
            <table>
                <tbody>
                    <tr>
                        <td>Asset Name</td> {/**Step2 and 3 */}
                        <td><input type="text" value={newAssetObj.employeeName} onChange={event=>setCommonHandlerForAsset({...newAssetObj,assetName:event.target.value})}/> </td>
                    </tr>
                    <tr>
                        <td>Description</td>  {/**Step2 and 3 */}
                        <td><input type="text" value={newAssetObj.salary} onChange={event=>setCommonHandlerForAsset({...newAssetObj,description:event.target.value})}/> </td>
                    </tr>
                </tbody>
            </table>
            <br/><button onClick={submitHandler} > Register</button>
           </center>
        </div>
    )
}