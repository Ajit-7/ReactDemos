import React from 'react';
import { EmployeeWithBugsFixed } from './Component/EmployeeWithBugsFixed';
import { EmployeeWithBugsFixed2 } from './Component/EmployeeWithBugsFixed2';
import { EmployeeWithBugsFixed1 } from './Component/EmployeeWithBugsFixed1';


function App() {
  return (
    <div className="App">
      {/* <EmployeeWithBugsFixed></EmployeeWithBugsFixed>     */}
      {/* <EmployeeWithBugsFixed1></EmployeeWithBugsFixed1> */}
      <EmployeeWithBugsFixed2></EmployeeWithBugsFixed2> 
    </div>
  );
}

export default App;
