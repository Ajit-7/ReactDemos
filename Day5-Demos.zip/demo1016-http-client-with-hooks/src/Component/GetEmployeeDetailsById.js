import React,{useState,useEffect} from 'react'
import axios from "axios"
import  "./EmployeeForm.module.css"
export function GetEmployeeDetailsById() {
    let initialEmployeeObjForInput = ""
    let initialEmployeeObjForRequest = "DefVal"
    let initialOutputEmployeeData=null
    let initialErrorMessage=""
    //A state should be created which is bound to the input element with handler binding
    const [newEmployeeObjForInput,setEmployeeObjForInputHandler] = useState(initialEmployeeObjForInput);
    //On click of the button state should be updated to another second state 
    //This is second state and respective handler
    const [newEmployeeObjForRequest,setEmployeeObjForRequestHandler] = useState(initialEmployeeObjForRequest);

    //A state should be created which will store the redeemed results, actual employee data obtained from the axios call
    const [newOutputEmployeeData,setOutputEmployeeDataRequestHandler] = useState(initialOutputEmployeeData);

    //A state should be created to store the error messages to display the error messages [Note: it will be used for conditional rendering]
    const [newErrorMessage,setErrorMessageHandler] = useState(initialErrorMessage);


    /*
    [Note: This can be achieved using a js function/handler bound to the onClick event of the button. This js 
        function/handler is responsible to initialize the second state with values entered by end user]
     */
    function submitHandler(){
        setEmployeeObjForRequestHandler(newEmployeeObjForInput)
    } 
    
    useEffect(()=>{
            //On Component Mounting, ignoring the axios call..
            if(newEmployeeObjForRequest!=="DefVal"){
                //Request for getting Employee Details for the entered id, using second state[newEmployeeObjForRequest]
                axios.get("http://localhost:8095/emp/controller/getDetailsById/"+newEmployeeObjForRequest)
                .then(
                    response=> {
                        console.log("Go result"+response);
                        console.log(response)
                        setErrorMessageHandler("") //Re-setting errorMessage in case of success
                        setOutputEmployeeDataRequestHandler(response.data) // setting response data to employeeList
                    }
                ).catch(error=>{
                        console.log(error)
                        setOutputEmployeeDataRequestHandler(null)//Re-setting employee data in case of error
                        setErrorMessageHandler(error.message)//setting the error message
                });
            }
            else{console.log("It is mounting phase hence by passing the axios call")}
    },[newEmployeeObjForRequest]) // effect works only on mounting and when updates are done to second state: newEmployeeObjForRequest
    return (
        <div>
              <center>
              <h2>Get Employee Details By Id</h2>
              
              {/*Input Element Bound to the state */}
              EmployeeId: <input name="employeeId" type="text" value={newEmployeeObjForInput} 
              onChange={event=>(setEmployeeObjForInputHandler(event.target.value))}></input>
              <button onClick={submitHandler}>Get Data</button> <br/><br/>
       
                    {/**Conditional Rendering if employee data exists display the employee data else display the errorMessage */}
                    <h4>{newOutputEmployeeData?
                                                         <table>
                                                         <tr>
                                                             <th>Employee Id</th>
                                                             <td>{newOutputEmployeeData.employeeId}</td>
                                                         </tr>
                                                         <tr>
                                                         
                                                             <th>Employee Name</th>
                                                             <td>{newOutputEmployeeData.employeeName}</td>
                                                         </tr>
                                                         <tr>
                                                             <th>Salary</th>
                                                             <td>{newOutputEmployeeData.salary}</td>
                                                         </tr>
                                                         <tr>
                                                             <th>Department Code</th>
                                                             <td>{newOutputEmployeeData.departmentCode}</td>                                            
                                                         </tr>
                                                         
                                                     </table>

                    :newErrorMessage}</h4>
              </center>  
        </div>
    )
}

