import React,{useState,useEffect} from 'react'
import axios from "axios"
import  "./EmployeeForm.module.css"
export function CreateEmployee() {
    let initialEmployeeObjForInput = {employeeName:'',salary:'',departmentCode:''}
    let initialEmployeeObjForRequest = "DefVal"
    let initialOutputData=null
    let initialErrorMessage=""
    //A state should be created which is bound to the input element with handler binding
    const [newEmployeeObjForInput,setEmployeeObjForInputHandler] = useState(initialEmployeeObjForInput);
    //On click of the button state should be updated to another second state 
    //This is second state and respective handler
    const [newEmployeeObjForRequest,setEmployeeObjForRequestHandler] = useState(initialEmployeeObjForRequest);

    //A state should be created which will store the redeemed results, actual employee data obtained from the axios call
    const [newOutputData,setOutputDataRequestHandler] = useState(initialOutputData);

    //A state should be created to store the error messages to display the error messages [Note: it will be used for conditional rendering]
    const [newErrorMessage,setErrorMessageHandler] = useState(initialErrorMessage);


    /*
    [Note: This can be achieved using a js function/handler bound to the onClick event of the button. This js 
        function/handler is responsible to initialize the second state with values entered by end user]
     */
    function submitHandler(){
        setEmployeeObjForRequestHandler(newEmployeeObjForInput)
    } 
    
    useEffect(()=>{
            //On Component Mounting, ignoring the axios call..
            if(newEmployeeObjForRequest!=="DefVal"){
                //Request for saving Employee Details for the entered employee data, using second state[newEmployeeObjForRequest]
                //sending the post data to the server
                axios.post("http://localhost:8095/emp/controller/addEmp", newEmployeeObjForRequest)
                .then(
                    response=> {
                        console.log("Go result"+response);
                        console.log(response)
                        setErrorMessageHandler("") //Re-setting errorMessage in case of success
                        setOutputDataRequestHandler(response.data) // setting response data to employeeList
                    }
                ).catch(error=>{
                        console.log(error)
                        setOutputDataRequestHandler(null)//Re-setting employee data in case of error
                        setErrorMessageHandler(error.message)//setting the error message
                });
            }
            else{console.log("It is mounting phase hence by passing the axios call")}
    },[newEmployeeObjForRequest]) // effect works only on mounting and when updates are done to second state: newEmployeeObjForRequest
    return (
        <div>
              <center>
              <h2>Create Employee</h2>
              {/*Input Element Bound to the state */}
                <table>
                    <tr>
                        <th>Employee Name</th>
                        <td><input  type="text" value={newEmployeeObjForInput.employeeName} onChange={event=>setEmployeeObjForInputHandler({...newEmployeeObjForInput,employeeName:event.target.value})}></input></td>
                    </tr>
                    <tr>
                        <th>Salary</th>
                        <td><input  type="text" value={newEmployeeObjForInput.salary} onChange={event=>setEmployeeObjForInputHandler({...newEmployeeObjForInput,salary:event.target.value})}></input></td>
                    </tr>
                    <tr>
                        <th>Department Code</th>
                        <td><input  type="text" value={newEmployeeObjForInput.departmentCode} onChange={event=>setEmployeeObjForInputHandler({...newEmployeeObjForInput,departmentCode:event.target.value})}></input></td>                                            
                    </tr>
                </table>
                <br/>
              <button onClick={submitHandler}>Create Employee</button> <br/><br/>
       
                    {/**Conditional Rendering if output data exists display the output data else display the errorMessage */}
                    <h4>{newOutputData?                            
                        newOutputData
                    :newErrorMessage}</h4>
              </center>  
        </div>
    )
}