import React from 'react';
import { GetAllEmployeeDetails } from './Component/GetAllEmployeeDetails';
import { GetEmployeeDetailsById } from './Component/GetEmployeeDetailsById';
import { CreateEmployee } from './Component/CreateEmployee';

function App() {
  return (
    <div className="App">
      {/* <GetAllEmployeeDetails></GetAllEmployeeDetails> */}

      {/* <GetEmployeeDetailsById></GetEmployeeDetailsById> */}

      <CreateEmployee></CreateEmployee>
    </div>
  );
}

export default App;
