import React from 'react';

import './App.css';
import { DisplayEmployeeDetails } from './Component/DisplayEmployeeDetails';
import { DisplayEmployeeDetailsDestructingProps } from './Component/DisplayEmployeeDetailsDestructingProps';

function App() {
  return (
    <div className="App">
        {/**Case1*/}
        <DisplayEmployeeDetails
          employeeId="1001"
          employeeName="Jack"
          salary="1000"
          departmentCode="121"
          >
        </DisplayEmployeeDetails>  

        {/**Case2: De-structured props */}
        {/* <DisplayEmployeeDetailsDestructingProps
        employeeId="1001"
        employeeName="Jack"
        salary="1000"
        departmentCode="121"
        >
        </DisplayEmployeeDetailsDestructingProps> */}

    </div>
  );
}

export default App;
