import React from 'react'
//CSS
import  "./EmployeeForm.module.css"
//Obtaining the props 
export function DisplayEmployeeDetails(props) {
    return (
        <div>
            {/**Displaying data using Props */}
            <center>
                <h2>Employee Details</h2>
                <table>
                    <tr>
                        <th>Employee Id</th>
                        <td>{props.employeeId}</td>
                    </tr>
                    <tr>
                        <th>Employee Name</th>
                        <td>{props.employeeName}</td>
                    </tr>
                    <tr>
                        <th>Salary</th>
                        <td>{props.salary}</td>
                    </tr>
                    <tr>
                        <th>Department Code</th>
                        <td>{props.departmentCode}</td>
                    </tr>
                </table>
            </center>
        </div>
    )
}

