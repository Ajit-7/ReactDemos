import React from 'react'

//CSS
import  "./EmployeeForm.module.css"

// Obtaining the attributes
// Order of the De-structuring does not matter.
// Name of the De-structured variable should be same as that of the actual attribute name 
export function DisplayEmployeeDetailsDestructingProps({salary,departmentCode,employeeId,employeeName}) {
    return (
        <div>
            {/**Displaying data using Props */}
            <center>
                <h2>Employee Details- De-structing Props</h2>
                <table>
                    <tr>
                        <th>Employee Id</th>
                        <td>{employeeId}</td>
                    </tr>
                    <tr>
                        <th>Employee Name</th>
                        <td>{employeeName}</td>
                    </tr>
                    <tr>
                        <th>Salary</th>
                        <td>{salary}</td>
                    </tr>
                    <tr>
                        <th>Department Code</th>
                        <td>{departmentCode}</td>
                    </tr>
                </table>
            </center>
        </div>
    )
}

