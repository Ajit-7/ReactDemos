import React, { Component } from 'react'

export class SearchEmployeeById extends Component {
    constructor(props) {
            super(props)
            let defText=this.props.defaultText;
            if(defText===null ||defText.length===0){
                    throw new Error("Please give valid for default text");
            }
            this.state = {
                employeeId:0,
                employeeData:this.props.defaultText,
                errorMessage:""
            }
    }
    getEmployeeDetails=(event)=>{
        try{
            event.preventDefault() // to prevent the refresh         
            this.setState({errorMessage:""}) //resetting the error message
            let num=parseInt(this.state.employeeId);
            let employeeData=null;
            
            if(num==0||num==null){
                throw new Error("Employee Id is Mandatory");
            }
            
            switch(num) {
                case 1001:
                    employeeData = {
                        employeeId:1001,
                        employeeName:"Jack",
                        salary:100001
                    };
                break;
                case 1002:
                    employeeData = {
                        employeeId:1002,
                        employeeName:"Stuart",
                        salary:20000
                    };
                break;
                case 1003:
                    employeeData = {
                        employeeId:1003,
                        employeeName:"Tim",
                        salary:30000
                    };
                break;
                default:
                    throw new Error("Please give valid Employee Id");

            }   
            //Setting Data to EmployeeData in case of success
            this.setState({employeeData})
        }catch(error){
            this.setState({errorMessage:error.message});
            this.setState({employeeData:""})
        }
    }

    onChangeHandler= (event)=>{
        this.setState({[event.target.name]:event.target.value}
            ,console.log("EmployeeId changed to: "+event.target.value))
    }

    render() {
        return (
            <div>
                <center>
                    <form onSubmit={this.getEmployeeDetails}>
                        <h2>Get Employee Details</h2>    

                        Please enter EmployeeId: <input value={this.setState.employeeId} name="employeeId" onChange={this.onChangeHandler}></input> <br/>
                        <input type="submit" value="Get Details"/>
                        <br/>
                        {this.state.errorMessage?this.state.errorMessage:JSON.stringify(this.state.employeeData)}
                    </form>
                </center>
            </div>
        )
    }
}
