import React, { Component } from 'react'
import { LifeCycleB } from './LifeCycleB';

export class LifeCycleA extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             name: 'Parents State'
        }
        console.log("From LifeCycleA constructor")    
    }
    
    //Make sure to include the static keyword as else method will be ignored 
    // during the lifecycle execution
    static getDerivedStateFromProps(props,state){
        console.log("From LifeCycleA getDerivedStateFromProps()")    
        return null; //This is done as it is not required to change the state, else it has to return a new updated state
    }

    componentDidMount(){
        console.log("LifeCycleA component did mount")
    }

    changeStateHandler=()=>{
        this.setState( 
            (prevState)=>({
                name: prevState.name+"_Ch"
            })
            ,()=>console.log("Call back: "+this.state.count)
        )
    }
    render() {
        console.log("From LifeCycleA render()")    
        return (
            <div>
                <h3>   LifeCycleA </h3>
                <button onClick={this.changeStateHandler}>Click To Change State</button>
                <LifeCycleB></LifeCycleB> 
            </div>
        )
    }

    //Update method
    shouldComponentUpdate(nextProps,nextState){
        console.log("LifeCycleA  shouldComponentUpdate");
        return true;
    }

    getSnapshotBeforeUpdate(prevProp,prevState){
        console.log("LifeCycleA getSnapshotBeforeUpdate");
        return null;
    }

    componentDidUpdate(prevProp,prevState,snapshot){
        console.log("LifeCycleA componentDidUpdate: "+snapshot)
    }

}