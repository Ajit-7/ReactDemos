import React from 'react';

import './App.css';

//importing the Component
import { ModifiedCustomMessage } from './Component/ModifiedCustomMessage';

function App() {
  return (
    <div className="App">
      <h1>Demo for Custom Default Message</h1>    

      {/**Using the Component1 */}
      <ModifiedCustomMessage customAttribute="From Tag1">
        <h3>Parent1: Child1</h3>
        <h3>Parent1: Child2</h3>
        <h3>Parent1: Child3</h3>
      </ModifiedCustomMessage>
      <hr/>
      {/**Using the Component2 */}
      <ModifiedCustomMessage customAttribute="From Tag2 No Child Element"/>

    </div>
  );
}

//exporting the App component as it will be imported and get used in  index.js
export default App;
