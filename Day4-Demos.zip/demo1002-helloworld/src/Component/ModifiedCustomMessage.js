import React from 'react'

/**This is Functional Component of React*/
/**Exporting the Component so that it can be used on the view */
/**This is accepting props which will refer to the attributes/ChildElements 
   passed from the place where Functional component is used */
export function ModifiedCustomMessage(props) {
    
    // Return method has JSX which will be transpilled by Bable to ES3
    // so that it is understood by majority of browsers.
    // Note that all the elements to be returned are part of the <div>
    // It is because multiple components cannot be retuned independently 
    return (
        <div>
                <center>
                    <h2>Welcome {props.customAttribute}</h2>
                    <h3>Passed in Child Elements are {props.children}</h3>
                </center>
        </div>
    )
}
