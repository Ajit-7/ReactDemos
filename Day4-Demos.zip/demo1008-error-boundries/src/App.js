import React from 'react';
import './App.css';
import { EmployeeFormCommenHandlerInLineV2 } from './Component/EmployeeFormCommenHandlerInLineV2';
import { SearchEmployeeById } from './Component/SearchEmployeeById';
import { CustomErrorBoundary } from './Component/CustomErrorBoundary';


function App() {
  return (
    <div className="App">
      <center>
        <h2>Employee Operations </h2>
        <table>
          <tr>
              
              <td>
                <CustomErrorBoundary>
                    <SearchEmployeeById defaultText=""></SearchEmployeeById>
                </CustomErrorBoundary>
              </td>
              <td>
                <EmployeeFormCommenHandlerInLineV2></EmployeeFormCommenHandlerInLineV2> 
              </td>
        </tr>
        </table>
       </center> 
    </div>
  );
}

export default App;

