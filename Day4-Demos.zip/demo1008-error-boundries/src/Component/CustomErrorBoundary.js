import React, { Component } from 'react'

export class CustomErrorBoundary extends Component {
    constructor(props) {
        super(props)
        this.state = {
             errorFlag:false,
             message: ""
        }
    }
    componentDidCatch(error,info){
       console.log("[Custom Error Boundary,componentDidCatch() ]: Logging Error..")
       console.log(error);     
       console.log(info)
    }
    static getDerivedStateFromError(error){
        console.log("[Custom Error Boundary,getDerivedStateFromError() ]: Configuring state variables..")
        return{
            errorFlag:true,
            message:error.message
        }
    }
    render() {
        if(this.state.errorFlag){
            return(
                <h3 > Some error happened, {this.state.message}</h3>
            )
        }
        else{
            return (
                <div>
                    {this.props.children}
                </div>
            )
        }
    }
}