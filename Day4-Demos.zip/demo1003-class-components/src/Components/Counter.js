import React, { Component } from 'react'

export class Counter extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             counterValue:0
        }
    }
    
    incrementhandlerCount = ()=>{
        this.setState((prevState)=>({
                             counterValue:prevState.counterValue+1
                          }),
                    ()=>console.log("Value Changed: "+this.state.counterValue)
                )
    }

    render() {
        return (
            <div>
                <h2>Increment Counter Example</h2>
                <h2>Counter Value is:  {this.state.counterValue}</h2>
                <button onClick={this.incrementhandlerCount}>Increment Counter</button>
            </div>
        )
    }
}
