import React, { Component } from 'react'
import { MessageDecorator } from './MessageDecorator';

export class CounterParameterized extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             counterValue:parseInt(this.props.counter),
             headingMessage:this.props.message,   
             child: this.props.childHeading
        }
    }
    
    incrementhandlerCount = ()=>{
        this.setState((prevState)=>({
                             counterValue:prevState.counterValue+1
                          }),
                    ()=>console.log("Value Changed: "+this.state.counterValue)
                )
    }

    render() {
        return (
            <div>
                {/* {this.props.message=""} */} {/** Un comment this line and observe that prop is read only*/}
                {this.state.child==="true"?<MessageDecorator 
                                messageDec={this.state.headingMessage}>
                                </MessageDecorator>: <h2>{this.state.headingMessage}</h2>}
                <h2>Counter Value is:  {this.state.counterValue}</h2>
                <button onClick={this.incrementhandlerCount}>Increment Counter</button>
               
            </div>
        )
    }
}
