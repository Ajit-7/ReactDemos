import React, { Component } from 'react'

export class MessageDecorator extends Component {
    render() {
        return (
            <div>
                <h2 style={{fontStyle:"italic", color:"green"}}>{this.props.messageDec}</h2>
            </div>
        )
    }
}