import React from 'react';

import './App.css';
import { Counter } from './Components/Counter';
import { CounterParameterized } from './Components/CounterParameterized';

function App() {
  return (
    <div className="App">
       <Counter></Counter> 

        {/* <table cellSpacing="50" style={{width:"100%"}}>
          <tr>
              <td><CounterParameterized counter="1001" message="First Counter"childHeading="true"></CounterParameterized> </td>
              <td><CounterParameterized counter="3001" message="Second Counter" childHeading="false"></CounterParameterized> </td>
          </tr>
          <tr>
              <td><CounterParameterized counter="5001" message="Third Counter" childHeading="false"></CounterParameterized> </td>
              <td><CounterParameterized counter="7001" message="Fourth Counter" childHeading="true">    
                  </CounterParameterized> 
                  
              </td>
          </tr>
        </table> */}

    </div>
  );
}

export default App;
