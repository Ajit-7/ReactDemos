import React from 'react';
import logo from './logo.svg';
import './App.css';
import { GetAllComponent } from './Components/GetAllComponent';
import { PostForm } from './Components/PostForm';
import { GetDetailsByIdComponent } from './Components/GetDetailsByIdComponent';

function App() {
  return (
    <div className="App">
      <center>
          {/*Fucntionality 1 */}
          <GetAllComponent></GetAllComponent>

          {/*Fucntionality 2 */}
          {/* <GetDetailsByIdComponent></GetDetailsByIdComponent> */}

          {/*Fucntionality 3 */}
          <PostForm></PostForm>
      </center>
    </div>
  );
}

export default App;
