import React, { Component } from 'react'
import axios from 'axios'
import "./EmployeeForm.module.css"
export class PostForm extends Component {
    
    constructor(props) {
        super(props)
        this.state = {
            employeeName:'',
            salary:'',
            departmentCode:'',
            message:''  ,     
            errorMessage:''
        }
    }
    //Commen handler
    changeHandler = event=>{
        this.setState(
            {[event.target.name]:event.target.value}
        )
    }
    //Submission Handler
    submitHandler = event=>{
        event.preventDefault();
        console.log(this.state);
        //sending the post data to the server
        axios.post("http://localhost:8095/emp/controller/addEmp", this.state)
        .then(
            response=> {	    //Case of Success, get the response data and update     
                                //the required state (message)
                console.log("Got result"+response);
                this.setState({message: response.data})
                //Clearing errorMessage in case of successs
                this.setState({errorMessage:""})
            }
        ).catch(error=>{
                console.log(error)
                this.setState({errorMessage:error.message})
                //Clearing message in case of error
                this.setState({message:""})
        });

    }
    render() {
        //this syntax is called de-structuring the state.
        //Destructured variable should have same name as that of the state variable.
        //this is done to prevent repeatedly writing this.state.employeeName, this.state.salary.. etc..
        const {employeeName,salary,deptartmentCode,message,errorMessage} = this.state
        return (
            <React.Fragment>
                <center>
                    <h2>Employee Registration Form</h2>
                    <form onSubmit={this.submitHandler}>
                        <table>
                                <tr>
                                    <td>Employee Name</td>
                                    <td><input type="text" name="employeeName" value={employeeName} onChange={this.changeHandler}/> </td>
                                </tr>    
                                <tr>
                                    <td>Salary</td>
                                    <td><input type="text" name="salary" value={salary} onChange={this.changeHandler}/> </td>
                                </tr>

                                <tr>
                                    <td>Department Code</td>
                                    <td><input type="text" name="departmentCode" value={deptartmentCode} onChange={this.changeHandler}/> </td>
                                </tr>
                        </table>
                        <br/>
                        <input type="submit" value="Submit"/>
                        <h4>{message?message:errorMessage}</h4>
                    </form> 
                </center>   
            </React.Fragment>
        )
    }
}