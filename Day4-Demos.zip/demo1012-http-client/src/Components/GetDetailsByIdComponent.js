import React, { Component } from 'react'
import axios from 'axios'
import "./EmployeeForm.module.css"
export class GetDetailsByIdComponent extends Component {
    constructor(props) {
        super(props)
        this.state = {
             employee:{},
             employeeId:"",
             errorMessage:"Please enter valid EmployeeId and Try out"
        }
    }
    //Submission Handler
    fetchResult=(event)=>{
        event.preventDefault()
        axios.get("http://localhost:8095/emp/controller/getDetailsById/"+this.state.employeeId)//async based / non blocking request
        .then(
             //Case of Success, get the response data and update     
             //the required state (employee)
            response=> {
                console.log("Go result"+response);
                this.setState({employee: response.data})
                //resetting the error message in case of success
                this.setState({errorMessage:""})
            }
        ).catch(error=>{
                console.log(">"+error)
                this.setState({errorMessage:error.message})
                //resetting the employee data in case of error
                this.setState({employee:{}})
        });

    }
    //Commen Handler
    handleOnChange = (event)=>{
        this.setState
                    ({[event.target.name]:event.target.value},
                        ()=>console.log("Entered EmployeeId is: "+this.state.employeeId)
                    )
    }
    render() {
        return (
            <div>
                    <h2>Get All Details By EmployeeId</h2>
                    EmployeeId: <input name="employeeId" type="text" value={this.state.employeeId} onChange={this.handleOnChange}></input>
                    <button onClick={this.fetchResult}>Get Data</button> <br/><br/>
                    {
                        //Conditional Display of Data using Ternary Operator
                        this.state.employee.employeeId!=null?
                                    <table>
                                        <tr>
                                            <th>Employee Id</th>
                                            <td>{this.state.employee.employeeId}</td>
                                        </tr>
                                        <tr>
                                        
                                            <th>Employee Name</th>
                                            <td>{this.state.employee.employeeName}</td>
                                        </tr>
                                        <tr>
                                            <th>Salary</th>
                                            <td>{this.state.employee.salary}</td>
                                        </tr>
                                        <tr>
                                            <th>Department Code</th>
                                            <td>{this.state.employee.departmentCode}</td>                                            
                                        </tr>
                                        
                                    </table>
                                :<h4>{this.state.errorMessage}</h4>
                    }    
                    
            </div>
        )
    }
}
