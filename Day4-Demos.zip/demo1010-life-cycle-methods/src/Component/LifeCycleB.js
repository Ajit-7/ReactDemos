import React, { Component } from 'react'

export class LifeCycleB extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             name: 'Child State'
        }
        console.log("From LifeCycleB constructor")    
    }
    
    //Make sure to include the static keyword as else method will be ignored 
    // during the lifecycle execution
    static getDerivedStateFromProps(props,state){
        console.log("From LifeCycleB getDerivedStateFromProps()")    
        return null; //This is done as it is not required to change the state, else it has to return a new updated state
    }

    componentDidMount(){
        console.log("LifeCycleB component did mount")
    }

    render() {
        console.log("From LifeCycleB render()")    
        return (
            <div>
                LifeCycleB
            </div>
        )
    }

}