import React, { Component } from 'react'
import { LifeCycleB } from './LifeCycleB';

export class LifeCycleA extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             name: 'Parent State'
        }
        console.log("From LifeCycleA constructor")    
    }
    
    //Make sure to include the static keyword as else method will be ignored 
    // during the lifecycle execution
    static getDerivedStateFromProps(props,state){
        console.log("From LifeCycleA getDerivedStateFromProps()")    
        return null; //This is done as it is not required to change the state, else it has to return a new updated state
    }

    componentDidMount(){
        console.log("LifeCycleA component did mount")
    }

    render() {
        console.log("From LifeCycleA render()")    
        return (
            <div>
                <h3>   LifeCycleA </h3>
                <LifeCycleB></LifeCycleB> 
            </div>
        )
    }

}