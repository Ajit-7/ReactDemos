import React from 'react';
import './App.css';
import { LifeCycleA } from './Component/LifeCycleA';

function App() {
  return (
    <div className="App">
      <LifeCycleA></LifeCycleA>
    </div>
  );
}

export default App;
