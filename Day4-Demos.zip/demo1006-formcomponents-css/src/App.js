import React from 'react';
import './App.css';
import { EmployeeFormCommenHandlerInLine } from './Component/EmployeeFormCommenHandlerInLine';
import { EmployeeFormCommenHandlerInLineV2 } from './Component/EmployeeFormCommenHandlerInLineV2';
import { EmployeeFormCommenHandlerExternalStyles } from './Component/EmployeeFormCommenHandlerExternalStyles';


function App() {
  return (
    <div className="App">
      {/*In Line Styles */}
      <EmployeeFormCommenHandlerInLine></EmployeeFormCommenHandlerInLine>
      {/* <EmployeeFormCommenHandlerInLineV2></EmployeeFormCommenHandlerInLineV2> */}

      {/**External Styles */}
      {/* <EmployeeFormCommenHandlerExternalStyles></EmployeeFormCommenHandlerExternalStyles>  */}
    </div>
  );
}

export default App;
