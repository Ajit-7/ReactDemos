import React from 'react';
import './App.css';
import { EmployeeForm } from './Component/EmployeeForm';
import { EmployeeFormCommenHandler } from './Component/EmployeeFormCommenHandler';

function App() {
  return (
     <EmployeeForm>  </EmployeeForm>
    // <EmployeeFormCommenHandler></EmployeeFormCommenHandler>
  );
}

export default App;
