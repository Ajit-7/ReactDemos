import React, { Component } from 'react'
import  "./EmployeeForm.module.css"
export class EmployeeFormCommenHandler extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
            employeeName:'',
            password:'',
            salary:'',
            departmentCode:'',
            gender:'',
            address:'',
            mailingList:false,
            checkAsset1:'',
            checkAsset2:'',
            checkAsset3:'',
            assetList:[]
        }
    }

   
    
    //Arrow functions need not to be bond in the constructor for this reference access
    //Observe back ticks it is ES6 standard
    handleSubmit =(event)=>{
            alert(`${this.state.employeeName}-
                 ${this.state.password}-
                 ${this.state.departmentCode}-
                 ${this.state.gender}-
                 ${this.state.salary}-
                 ${this.state.address}-
                 ${this.state.mailingList}-
                 ${this.state.assetList[0]}-${this.state.assetList[1]}-${this.state.assetList[2]}`);
        event.preventDefault() // to prevent the refresh         
    }
    
    //Used to set the assetList
    setAssetList=(name,value)=>{
        if(name==="checkAsset1"){	
            this.setState({
                assetList:[value,this.state.checkAsset2,this.state.checkAsset3]
            })
        }else if(name==="checkAsset2"){
            this.setState({
                assetList:[this.state.checkAsset1,value,this.state.checkAsset3]
            })    
        }else{
            this.setState({
                assetList:[this.state.checkAsset1,this.state.checkAsset2,value]
            })    
        }	
       console.log("Asset list updated for Field: "+name+",Changed Value: "+value)
    }

    //Commen handler
    handlerCommenValuesUpdate=(event)=>{
        let name = event.target.name;
        let value = event.target.value;
        if(event.target.type!== "checkbox"){//if check box is selected get the value from the value attribute of checkbox. 
                                           //Else leave it blank
            //evt.target.name would give the field name which can be any of the names field names like 
	        //"employeeName","password" etc
	        //name is used to target the key on our `state` object with the same name, using bracket syntax
            //{[name]: value} here bracket is [name]

            this.setState({[name]: value},
                ()=>console.log("Other logs Field: "+name+", Changed Value: "+value));
        }else {
            if(event.target.name!== "mailingList"){ //case of assets check box
                let dummyVar="";
                if(event.target.checked){
                    dummyVar =  event.target.value
                }
                this.setState(
                    {[name]: dummyVar},
                    ()=>{
                        this.setAssetList(name,dummyVar) //Invoking the setAssetList from call back
                        console.log("Checkbox log, Field: "+name+", Changed Value: "+dummyVar)}
                    );         
            }
            else{
                this.setState({[name]: event.target.checked},
                    ()=>console.log("Mailing list Log, Field: "+name+", Changed Value: "+value));    
            }    
        }
    }
    render() {
        return (
            <div>
                <center>
                    <form onSubmit={this.handleSubmit}>
                <h2>Employee Registration Form</h2>   
                    <table>
                        <tbody>
                                <tr>
                                <th>Employee Name</th>
                                <td><input name="employeeName" type="text"value={this.state.employeeName} onChange= {this.handlerCommenValuesUpdate}/></td>
                                </tr>
                                <tr>
                                <th>Password</th>
                                <td><input name="password" type="password" value={this.state.password} onChange= {this.handlerCommenValuesUpdate}/></td>
                                </tr>
                                <tr>
                                <th>Salary</th>
                                <td><input name="salary" type="text" value={this.state.salary} onChange= {this.handlerCommenValuesUpdate}/></td>
                                </tr>
                                <tr>    
                                <th>Department Code</th>
                                <td>
                                    <select name="departmentCode" value={this.state.departmentCode} onChange= {this.handlerCommenValuesUpdate}>
                                        <option value="">--Select--</option>
                                        <option value="1001">Java</option>
                                        <option value="1002">Dotnet</option>
                                    </select>
                                </td>
                                
                                </tr>
                                <tr>
                                <th>Gender</th>
                                <td>
                                    <input type="radio" name="gender" value="M" checked={this.state.gender === "M"} onChange={this.handlerCommenValuesUpdate} />Male
                                    <input type="radio" name="gender" value="F"checked={this.state.gender === "F"} onChange={this.handlerCommenValuesUpdate}/>Female
                                </td>
                                </tr>
                                <tr>
                                <th>Address</th>
                                <td>
                                    <textarea name="address" cols="51" rows="5" value={this.state.address} onChange={this.handlerCommenValuesUpdate}></textarea>
                                </td>
                                
                                </tr>
                                <tr>
                                <th>Mailing List</th>
                                <td>
                                    
                                        <input  name="mailingList" type="checkbox"  checked={this.state.mailingList} onChange={this.handlerCommenValuesUpdate}/>
                                    
                                </td>
                                </tr>
                                <tr>
                                <th>Assets</th>
                                <td>
                                    
                                        <input  name="checkAsset1" value="M" type="checkbox"  checked={this.state.checkAsset1} onChange={this.handlerCommenValuesUpdate}/> Mobile
                                        <input  name="checkAsset2" value="L"  type="checkbox"  checked={this.state.checkAsset2} onChange={this.handlerCommenValuesUpdate}/> Laptop
                                        <input  name="checkAsset3" value="C"  type="checkbox"  checked={this.state.checkAsset3} onChange={this.handlerCommenValuesUpdate}/> Cabin
                                    
                                </td>
                                </tr>
                        </tbody>
                    </table>
                    <input type="Submit"value="Register" />
                    </form>
                </center>
            </div>
        )
    }
}