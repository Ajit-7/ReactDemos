import React, { Component } from 'react'
import  "./EmployeeForm.module.css"
export class EmployeeForm extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
            employeeName:'',
            password:'',
            salary:'',
            departmentCode:'',
            gender:'',
            address:'',
            mailingList:false,
            checkAsset1:'',
            checkAsset2:'',
            checkAsset3:'',
            assetList:[]
        }
    }

    handleTextEmployeeNameChange=(event)=> {
        this.setState({
            employeeName: event.target.value
        },()=>console.log('Changed Value is :'+this.state.employeeName));
    }
    handleTextPasswordChange=(event)=> {
        this.setState({
            password: event.target.value
        },()=>console.log('Changed Value is :'+this.state.password));
    }
    handleTextSalaryChange=(event)=> {
        this.setState({
            salary: event.target.value
        },()=>console.log('Changed Value is :'+this.state.salary));
    }
    handleDropDownDepartmentChange=(event)=>{
        this.setState({
            departmentCode: event.target.value
        },()=>console.log('Changed Value is :'+this.state.departmentCode));
    }
    handleTextAreaAddressChange=(event)=>{
        this.setState({
            address: event.target.value
        },()=>console.log('Changed Value is :'+this.state.address));
    }
    handleRadioGenderChange=(event)=>{
        this.setState({
            gender: event.target.value
        },()=>console.log('Changed Value is :'+this.state.gender));
    }
    handleCheckBoxMailingListChange=(event)=> {
        this.setState({
           mailingList: event.target.checked
        },()=>console.log('Changed Value is :'+this.state.mailingList));
    }
    handleCheckBoxAsset1Change=(event)=> {
        var dummyVarStatus=""
        if(event.target.checked){
            dummyVarStatus="M"
        }
        this.setState({
           checkAsset1: dummyVarStatus,
           assetList:[dummyVarStatus,this.state.checkAsset2,this.state.checkAsset3]
        },()=>console.log('Changed Value is :'+this.state.checkAsset1));
    }
    handleCheckBoxAsset2Change=(event)=> {
        var dummyVarStatus=""
        if(event.target.checked){
            dummyVarStatus="L"
        }
        this.setState({
           checkAsset2: dummyVarStatus,
           assetList:[this.state.checkAsset1,dummyVarStatus,this.state.checkAsset3]
        },()=>console.log('Changed Value is :'+this.state.checkAsset2));
    }
    handleCheckBoxAsset3Change=(event)=> {
        var dummyVarStatus=""
        if(event.target.checked){
            dummyVarStatus="C"
        }
        this.setState({
            checkAsset3: dummyVarStatus,
            assetList:[this.state.checkAsset1,this.state.checkAsset2,dummyVarStatus]
        },()=>console.log('Changed Value is :'+this.state.checkAsset3));
    }
    //Arrow functions need not to be bond in the constructor for this reference access
    //Observe back ticks it is ES6 standard
    handleSubmit =(event)=>{
            alert(`${this.state.employeeName}-
                 ${this.state.password}-
                 ${this.state.departmentCode}-
                 ${this.state.gender}-
                 ${this.state.salary}-
                 ${this.state.address}-
                 ${this.state.mailingList}-
                 ${this.state.assetList[0]}-${this.state.assetList[1]}-${this.state.assetList[2]}`);
        event.preventDefault() // to prevent the refresh         
    }
      
    render() {
        return (
            <div>
                <center>
                    <form onSubmit={this.handleSubmit}>
                <h2>Employee Registration Form</h2>   
                    <table>
                        <tbody>
                                <tr>
                                <th>Employee Name</th>
                                <td><input type="text"value={this.state.employeeName} onChange= {this.handleTextEmployeeNameChange}/></td>
                                </tr>
                                <tr>
                                <th>Password</th>
                                <td><input type="password" value={this.state.password} onChange= {this.handleTextPasswordChange}/></td>
                                </tr>
                                <tr>
                                <th>Salary</th>
                                <td><input type="text" value={this.state.salary} onChange= {this.handleTextSalaryChange}/></td>
                                </tr>
                                <tr>    
                                <th>Department Code</th>
                                <td>
                                    <select value={this.state.departmentCode} onChange= {this.handleDropDownDepartmentChange}>
                                        <option value="0">--Select--</option>
                                        <option value="1001">Java</option>
                                        <option value="1002">Dotnet</option>
                                    </select>
                                </td>
                                
                                </tr>
                                <tr>
                                <th>Gender</th>
                                <td>
                                    <input type="radio" name="gender" value="M" checked={this.state.gender === "M"} onChange={this.handleRadioGenderChange} />Male
                                    <input type="radio" name="gender" value="F"checked={this.state.gender === "F"} onChange={this.handleRadioGenderChange}/>Female
                                </td>
                                </tr>
                                <tr>
                                <th>Address</th>
                                <td>
                                    <textarea cols="51" rows="5" value={this.state.address} onChange={this.handleTextAreaAddressChange}></textarea>
                                </td>
                                
                                </tr>
                                <tr>
                                <th>Mailing List</th>
                                <td>
                                    
                                        <input  type="checkbox"  checked={this.state.mailingList} onChange={this.handleCheckBoxMailingListChange}/>
                                    
                                </td>
                                </tr>
                                <tr>
                                <th>Assets</th>
                                <td>
                                    
                                        <input  type="checkbox"  checked={this.state.checkAsset1} onChange={this.handleCheckBoxAsset1Change}/> Mobile
                                        <input  type="checkbox"  checked={this.state.checkAsset2} onChange={this.handleCheckBoxAsset2Change}/> Laptop
                                        <input  type="checkbox"  checked={this.state.checkAsset3} onChange={this.handleCheckBoxAsset3Change}/> Cabin
                                    
                                </td>
                                </tr>
                        </tbody>
                    </table>
                    <input type="Submit"value="Register" />
                    </form>
                </center>
            </div>
        )
    }
}